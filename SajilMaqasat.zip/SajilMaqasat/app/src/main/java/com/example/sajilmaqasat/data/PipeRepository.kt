package com.example.sajilmaqasat.data

import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PipeRepository @Inject constructor(
    private val dao: PipeRecordDao
) {
    fun getAll(): Flow<List<PipeRecord>> = dao.getAll()

    fun search(query: String): Flow<List<PipeRecord>> = dao.searchBySize(query)

    suspend fun getById(id: Long): PipeRecord? = dao.getById(id)

    suspend fun insert(record: PipeRecord): Long = dao.insert(record)

    suspend fun update(record: PipeRecord) = dao.update(record)

    suspend fun delete(record: PipeRecord) = dao.delete(record)
}
