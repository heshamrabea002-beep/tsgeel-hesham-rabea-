package com.example.sajilmaqasat.ui.addedit

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.sajilmaqasat.data.PipeRecord
import com.example.sajilmaqasat.data.PipeRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class AddEditUiState(
    val id: Long = 0,
    val pipeSize: String = "",
    val materialType: String = "",
    val machineSpeed: String = "",
    val rpm1: String = "",
    val rpm2: String = "",
    val rpm3: String = "",
    val furnaceTemps: List<String> = emptyList(),
    val headTemps: List<String> = emptyList(),
    val suctionDiameter: String = "",
    val suctionType: String = "",
    val suctionRate: String = "",
    val diameterAfterTank1: String = "",
    val diameterAtLineEnd: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val isEditMode: Boolean = false,
    val isSaved: Boolean = false
)

@HiltViewModel
class AddEditViewModel @Inject constructor(
    private val repository: PipeRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(AddEditUiState())
    val uiState: StateFlow<AddEditUiState> = _uiState.asStateFlow()

    private var loadedForId: Long? = null

    fun loadRecord(id: Long) {
        if (loadedForId == id) return
        loadedForId = id
        viewModelScope.launch {
            val record = repository.getById(id) ?: return@launch
            _uiState.value = AddEditUiState(
                id = record.id,
                pipeSize = record.pipeSize,
                materialType = record.materialType,
                machineSpeed = record.machineSpeed,
                rpm1 = record.rpm1,
                rpm2 = record.rpm2,
                rpm3 = record.rpm3,
                furnaceTemps = record.furnaceTemps.split(",").filter { it.isNotBlank() },
                headTemps = record.headTemps.split(",").filter { it.isNotBlank() },
                suctionDiameter = record.suctionDiameter,
                suctionType = record.suctionType,
                suctionRate = record.suctionRate,
                diameterAfterTank1 = record.diameterAfterTank1,
                diameterAtLineEnd = record.diameterAtLineEnd,
                notes = record.notes,
                createdAt = record.createdAt,
                isEditMode = true
            )
        }
    }

    fun updateField(update: (AddEditUiState) -> AddEditUiState) {
        _uiState.value = update(_uiState.value)
    }

    fun addFurnaceTemp() {
        _uiState.value = _uiState.value.copy(furnaceTemps = _uiState.value.furnaceTemps + "")
    }

    fun removeFurnaceTemp(index: Int) {
        _uiState.value = _uiState.value.copy(
            furnaceTemps = _uiState.value.furnaceTemps.toMutableList().apply { removeAt(index) }
        )
    }

    fun updateFurnaceTemp(index: Int, value: String) {
        _uiState.value = _uiState.value.copy(
            furnaceTemps = _uiState.value.furnaceTemps.toMutableList().apply { set(index, value) }
        )
    }

    fun addHeadTemp() {
        _uiState.value = _uiState.value.copy(headTemps = _uiState.value.headTemps + "")
    }

    fun removeHeadTemp(index: Int) {
        _uiState.value = _uiState.value.copy(
            headTemps = _uiState.value.headTemps.toMutableList().apply { removeAt(index) }
        )
    }

    fun updateHeadTemp(index: Int, value: String) {
        _uiState.value = _uiState.value.copy(
            headTemps = _uiState.value.headTemps.toMutableList().apply { set(index, value) }
        )
    }

    fun save() {
        viewModelScope.launch {
            val s = _uiState.value
            val record = PipeRecord(
                id = s.id,
                pipeSize = s.pipeSize,
                materialType = s.materialType,
                machineSpeed = s.machineSpeed,
                rpm1 = s.rpm1,
                rpm2 = s.rpm2,
                rpm3 = s.rpm3,
                furnaceTemps = s.furnaceTemps.joinToString(","),
                headTemps = s.headTemps.joinToString(","),
                suctionDiameter = s.suctionDiameter,
                suctionType = s.suctionType,
                suctionRate = s.suctionRate,
                diameterAfterTank1 = s.diameterAfterTank1,
                diameterAtLineEnd = s.diameterAtLineEnd,
                notes = s.notes,
                createdAt = s.createdAt
            )
            if (s.isEditMode) {
                repository.update(record)
            } else {
                repository.insert(record)
            }
            _uiState.value = _uiState.value.copy(isSaved = true)
        }
    }
}
