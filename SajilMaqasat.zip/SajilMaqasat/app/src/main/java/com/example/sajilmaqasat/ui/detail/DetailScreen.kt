package com.example.sajilmaqasat.ui.detail

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.sajilmaqasat.util.CsvExporter
import com.example.sajilmaqasat.util.PdfExporter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(
    recordId: Long,
    onBack: () -> Unit,
    onEdit: (Long) -> Unit,
    onDeleted: () -> Unit,
    viewModel: DetailViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    val record by viewModel.record.collectAsState()
    var showDeleteDialog by remember { mutableStateOf(false) }

    LaunchedEffect(recordId) { viewModel.loadRecord(recordId) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("تفاصيل المقاس ${record?.pipeSize ?: ""}") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                actions = {
                    IconButton(onClick = { record?.id?.let(onEdit) }) {
                        Icon(Icons.Filled.Edit, contentDescription = "تعديل")
                    }
                    IconButton(onClick = {
                        record?.let {
                            val uri = CsvExporter.exportSingle(context, it)
                            CsvExporter.shareCsv(context, uri)
                        }
                    }) {
                        Icon(Icons.Filled.Share, contentDescription = "تصدير Excel")
                    }
                    IconButton(onClick = {
                        record?.let { PdfExporter.printRecords(context, listOf(it)) }
                    }) {
                        Icon(Icons.Filled.Print, contentDescription = "تصدير PDF")
                    }
                    IconButton(onClick = { showDeleteDialog = true }) {
                        Icon(Icons.Filled.Delete, contentDescription = "حذف")
                    }
                }
            )
        }
    ) { padding ->
        record?.let { r ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    DetailCard(title = "بيانات أساسية") {
                        DetailRow("مقاس الماسورة", r.pipeSize)
                        DetailRow("نوع الخامة", r.materialType)
                    }
                }
                item {
                    DetailCard(title = "السرعات") {
                        DetailRow("سرعة الماكينة", r.machineSpeed)
                        DetailRow("RPM ماكينة 1", r.rpm1)
                        DetailRow("RPM ماكينة 2", r.rpm2)
                        DetailRow("RPM ماكينة 3", r.rpm3)
                    }
                }
                item {
                    DetailCard(title = "حرارات الفرن") {
                        val temps = r.furnaceTemps.split(",").filter { it.isNotBlank() }
                        if (temps.isEmpty()) {
                            DetailRow("حرارات الفرن", "")
                        } else {
                            temps.forEachIndexed { i, t -> DetailRow("منطقة ${i + 1}", t) }
                        }
                    }
                }
                item {
                    DetailCard(title = "حرارات الرأس") {
                        val temps = r.headTemps.split(",").filter { it.isNotBlank() }
                        if (temps.isEmpty()) {
                            DetailRow("حرارات الرأس", "")
                        } else {
                            temps.forEachIndexed { i, t -> DetailRow("منطقة ${i + 1}", t) }
                        }
                    }
                }
                item {
                    DetailCard(title = "الشفاط") {
                        DetailRow("قطر الشفاط", r.suctionDiameter)
                        DetailRow("نوع الشفاط", r.suctionType)
                        DetailRow("معدل الشفط", r.suctionRate)
                    }
                }
                item {
                    DetailCard(title = "الأقطار") {
                        DetailRow("القطر بعد الحوض الأول", r.diameterAfterTank1)
                        DetailRow("القطر في نهاية الخط", r.diameterAtLineEnd)
                    }
                }
                item {
                    DetailCard(title = "ملاحظات") {
                        DetailRow("ملاحظات", r.notes)
                    }
                }
            }
        }
    }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("تأكيد الحذف") },
            text = { Text("هل أنت متأكد من حذف هذا التسجيل؟") },
            confirmButton = {
                TextButton(onClick = {
                    showDeleteDialog = false
                    viewModel.deleteRecord(onDeleted)
                }) { Text("حذف", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) { Text("إلغاء") }
            }
        )
    }
}

@Composable
private fun DetailCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            content()
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value.ifBlank { "—" }, fontSize = 16.sp, fontWeight = FontWeight.Medium)
    }
}
