package com.example.sajilmaqasat.ui.detail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.sajilmaqasat.data.PipeRecord
import com.example.sajilmaqasat.data.PipeRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DetailViewModel @Inject constructor(
    private val repository: PipeRepository
) : ViewModel() {

    private val _record = MutableStateFlow<PipeRecord?>(null)
    val record: StateFlow<PipeRecord?> = _record.asStateFlow()

    private var loadedForId: Long? = null

    fun loadRecord(id: Long) {
        if (loadedForId == id) return
        loadedForId = id
        viewModelScope.launch {
            _record.value = repository.getById(id)
        }
    }

    fun deleteRecord(onDeleted: () -> Unit) {
        viewModelScope.launch {
            _record.value?.let {
                repository.delete(it)
                onDeleted()
            }
        }
    }
}
