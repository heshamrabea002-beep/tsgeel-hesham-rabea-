package com.example.sajilmaqasat.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "pipe_records")
data class PipeRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val pipeSize: String = "",
    val materialType: String = "",
    val machineSpeed: String = "",
    val rpm1: String = "",
    val rpm2: String = "",
    val rpm3: String = "",
    // Stored as comma separated text, e.g. "180,185,190"
    val furnaceTemps: String = "",
    val headTemps: String = "",
    val suctionDiameter: String = "",
    val suctionType: String = "",
    val suctionRate: String = "",
    val diameterAfterTank1: String = "",
    val diameterAtLineEnd: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
