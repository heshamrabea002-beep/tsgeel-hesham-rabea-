package com.example.sajilmaqasat.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface PipeRecordDao {

    @Query("SELECT * FROM pipe_records ORDER BY createdAt DESC")
    fun getAll(): Flow<List<PipeRecord>>

    @Query("SELECT * FROM pipe_records WHERE pipeSize LIKE '%' || :query || '%' ORDER BY createdAt DESC")
    fun searchBySize(query: String): Flow<List<PipeRecord>>

    @Query("SELECT * FROM pipe_records WHERE id = :id")
    suspend fun getById(id: Long): PipeRecord?

    @Insert
    suspend fun insert(record: PipeRecord): Long

    @Update
    suspend fun update(record: PipeRecord)

    @Delete
    suspend fun delete(record: PipeRecord)
}
