package com.example.sajilmaqasat.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [PipeRecord::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun pipeRecordDao(): PipeRecordDao
}
