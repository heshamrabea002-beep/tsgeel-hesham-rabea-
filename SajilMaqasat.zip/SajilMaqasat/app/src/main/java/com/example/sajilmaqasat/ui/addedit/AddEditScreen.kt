package com.example.sajilmaqasat.ui.addedit

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditScreen(
    recordId: Long?,
    onBack: () -> Unit,
    onSaved: () -> Unit,
    viewModel: AddEditViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()

    LaunchedEffect(recordId) {
        if (recordId != null) viewModel.loadRecord(recordId)
    }

    LaunchedEffect(state.isSaved) {
        if (state.isSaved) onSaved()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (state.isEditMode) "تعديل" else "تسجيل جديد") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                FormCard(title = "بيانات أساسية") {
                    LabeledField("مقاس الماسورة", state.pipeSize, KeyboardType.Number) { v ->
                        viewModel.updateField { it.copy(pipeSize = v) }
                    }
                    LabeledField("نوع الخامة", state.materialType) { v ->
                        viewModel.updateField { it.copy(materialType = v) }
                    }
                }
            }

            item {
                FormCard(title = "السرعات") {
                    LabeledField("سرعة الماكينة", state.machineSpeed, KeyboardType.Number) { v ->
                        viewModel.updateField { it.copy(machineSpeed = v) }
                    }
                    LabeledField("RPM ماكينة 1", state.rpm1, KeyboardType.Number) { v ->
                        viewModel.updateField { it.copy(rpm1 = v) }
                    }
                    LabeledField("RPM ماكينة 2", state.rpm2, KeyboardType.Number) { v ->
                        viewModel.updateField { it.copy(rpm2 = v) }
                    }
                    LabeledField("RPM ماكينة 3", state.rpm3, KeyboardType.Number) { v ->
                        viewModel.updateField { it.copy(rpm3 = v) }
                    }
                }
            }

            item {
                DynamicFieldsCard(
                    title = "حرارات الفرن",
                    values = state.furnaceTemps,
                    onAdd = viewModel::addFurnaceTemp,
                    onRemove = viewModel::removeFurnaceTemp,
                    onChange = viewModel::updateFurnaceTemp
                )
            }

            item {
                DynamicFieldsCard(
                    title = "حرارات الرأس",
                    values = state.headTemps,
                    onAdd = viewModel::addHeadTemp,
                    onRemove = viewModel::removeHeadTemp,
                    onChange = viewModel::updateHeadTemp
                )
            }

            item {
                FormCard(title = "الشفاط") {
                    LabeledField("قطر الشفاط", state.suctionDiameter, KeyboardType.Number) { v ->
                        viewModel.updateField { it.copy(suctionDiameter = v) }
                    }
                    LabeledField("نوع الشفاط", state.suctionType) { v ->
                        viewModel.updateField { it.copy(suctionType = v) }
                    }
                    LabeledField("معدل الشفط", state.suctionRate, KeyboardType.Number) { v ->
                        viewModel.updateField { it.copy(suctionRate = v) }
                    }
                }
            }

            item {
                FormCard(title = "الأقطار") {
                    LabeledField(
                        "القطر بعد الحوض الأول",
                        state.diameterAfterTank1,
                        KeyboardType.Number
                    ) { v -> viewModel.updateField { it.copy(diameterAfterTank1 = v) } }
                    LabeledField(
                        "القطر في نهاية الخط",
                        state.diameterAtLineEnd,
                        KeyboardType.Number
                    ) { v -> viewModel.updateField { it.copy(diameterAtLineEnd = v) } }
                }
            }

            item {
                FormCard(title = "ملاحظات") {
                    OutlinedTextField(
                        value = state.notes,
                        onValueChange = { v -> viewModel.updateField { it.copy(notes = v) } },
                        modifier = Modifier.fillMaxWidth().height(120.dp),
                        placeholder = { Text("اكتب ملاحظاتك هنا") }
                    )
                }
            }

            item {
                Button(
                    onClick = { viewModel.save() },
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) {
                    Text("حفظ", style = MaterialTheme.typography.titleMedium)
                }
            }
        }
    }
}

@Composable
private fun FormCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        androidx.compose.foundation.layout.Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            content()
        }
    }
}

@Composable
private fun LabeledField(
    label: String,
    value: String,
    keyboardType: KeyboardType = KeyboardType.Text,
    onChange: (String) -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType)
    )
}

@Composable
private fun DynamicFieldsCard(
    title: String,
    values: List<String>,
    onAdd: () -> Unit,
    onRemove: (Int) -> Unit,
    onChange: (Int, String) -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        androidx.compose.foundation.layout.Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                TextButton(onClick = onAdd) {
                    Text("+ إضافة")
                }
            }
            values.forEachIndexed { index, value ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = value,
                        onValueChange = { onChange(index, it) },
                        label = { Text("منطقة ${index + 1}") },
                        modifier = Modifier.fillMaxWidth().weight(1f),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                    IconButton(onClick = { onRemove(index) }) {
                        Icon(Icons.Filled.Delete, contentDescription = "حذف")
                    }
                }
            }
        }
    }
}
