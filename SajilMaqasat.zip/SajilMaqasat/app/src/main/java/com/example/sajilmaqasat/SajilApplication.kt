package com.example.sajilmaqasat

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class SajilApplication : Application()
