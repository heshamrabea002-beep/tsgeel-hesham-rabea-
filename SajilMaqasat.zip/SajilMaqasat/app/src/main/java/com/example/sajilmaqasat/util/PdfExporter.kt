package com.example.sajilmaqasat.util

import android.content.Context
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import com.example.sajilmaqasat.data.PipeRecord

object PdfExporter {

    private fun fieldRow(label: String, value: String): String {
        val v = if (value.isBlank()) "—" else value
        return "<tr><td class='label'>$label</td><td class='value'>$v</td></tr>"
    }

    private fun temperaturesRow(label: String, csv: String): String {
        val parts = csv.split(",").filter { it.isNotBlank() }
        val value = if (parts.isEmpty()) "—" else parts.joinToString(" | ")
        return fieldRow(label, value)
    }

    private fun recordToHtml(r: PipeRecord): String {
        val sb = StringBuilder()
        sb.append("<div class='record'>")
        sb.append("<h2>مقاس الماسورة: ${r.pipeSize.ifBlank { "—" }}</h2>")
        sb.append("<table>")
        sb.append(fieldRow("نوع الخامة", r.materialType))
        sb.append(fieldRow("سرعة الماكينة", r.machineSpeed))
        sb.append(fieldRow("RPM ماكينة 1", r.rpm1))
        sb.append(fieldRow("RPM ماكينة 2", r.rpm2))
        sb.append(fieldRow("RPM ماكينة 3", r.rpm3))
        sb.append(temperaturesRow("حرارات الفرن", r.furnaceTemps))
        sb.append(temperaturesRow("حرارات الرأس", r.headTemps))
        sb.append(fieldRow("قطر الشفاط", r.suctionDiameter))
        sb.append(fieldRow("نوع الشفاط", r.suctionType))
        sb.append(fieldRow("معدل الشفط", r.suctionRate))
        sb.append(fieldRow("القطر بعد الحوض الأول", r.diameterAfterTank1))
        sb.append(fieldRow("القطر في نهاية الخط", r.diameterAtLineEnd))
        sb.append(fieldRow("ملاحظات", r.notes))
        sb.append("</table></div>")
        return sb.toString()
    }

    private fun buildHtml(records: List<PipeRecord>): String {
        val body = records.joinToString("\n") { recordToHtml(it) }
        return """
            <html dir="rtl" lang="ar">
            <head>
                <meta charset="utf-8"/>
                <style>
                    body { font-family: sans-serif; padding: 16px; }
                    h2 { color: #2E7D32; border-bottom: 2px solid #2E7D32; padding-bottom: 4px; }
                    table { width: 100%; border-collapse: collapse; margin-bottom: 24px; }
                    td { border: 1px solid #cccccc; padding: 8px; font-size: 14px; text-align: right; }
                    .label { background-color: #F6F8FA; font-weight: bold; width: 40%; color: #2E7D32; }
                    .value { font-weight: normal; }
                    .record { margin-bottom: 32px; page-break-inside: avoid; }
                </style>
            </head>
            <body>
                $body
            </body>
            </html>
        """.trimIndent()
    }

    /**
     * Renders the records as HTML inside an off-screen WebView and hands the result
     * to Android's native PrintManager, which lets the user save it as a PDF file.
     */
    fun printRecords(context: Context, records: List<PipeRecord>, jobName: String = "سجل_المقاسات") {
        if (records.isEmpty()) return

        val webView = WebView(context)
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                val printManager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
                val printAdapter = view.createPrintDocumentAdapter(jobName)
                printManager.print(
                    jobName,
                    printAdapter,
                    PrintAttributes.Builder().build()
                )
            }
        }
        webView.loadDataWithBaseURL(null, buildHtml(records), "text/html", "UTF-8", null)
    }
}
