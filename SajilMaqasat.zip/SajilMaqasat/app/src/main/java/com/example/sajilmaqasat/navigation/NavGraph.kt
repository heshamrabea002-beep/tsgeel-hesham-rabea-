package com.example.sajilmaqasat.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.sajilmaqasat.ui.addedit.AddEditScreen
import com.example.sajilmaqasat.ui.detail.DetailScreen
import com.example.sajilmaqasat.ui.home.HomeScreen

object Routes {
    const val HOME = "home"
    const val ADD_EDIT = "add_edit?recordId={recordId}"
    const val DETAIL = "detail/{recordId}"

    fun addEdit(recordId: Long? = null) = "add_edit?recordId=${recordId ?: -1}"
    fun detail(recordId: Long) = "detail/$recordId"
}

@Composable
fun NavGraph() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = Routes.HOME) {

        composable(Routes.HOME) {
            HomeScreen(
                onAddClick = { navController.navigate(Routes.addEdit()) },
                onItemClick = { id -> navController.navigate(Routes.detail(id)) }
            )
        }

        composable(
            route = Routes.ADD_EDIT,
            arguments = listOf(
                navArgument("recordId") {
                    type = NavType.LongType
                    defaultValue = -1L
                }
            )
        ) { backStackEntry ->
            val recordId = backStackEntry.arguments?.getLong("recordId") ?: -1L
            AddEditScreen(
                recordId = if (recordId == -1L) null else recordId,
                onBack = { navController.popBackStack() },
                onSaved = { navController.popBackStack() }
            )
        }

        composable(
            route = Routes.DETAIL,
            arguments = listOf(navArgument("recordId") { type = NavType.LongType })
        ) { backStackEntry ->
            val recordId = backStackEntry.arguments?.getLong("recordId") ?: 0L
            DetailScreen(
                recordId = recordId,
                onBack = { navController.popBackStack() },
                onEdit = { id -> navController.navigate(Routes.addEdit(id)) },
                onDeleted = { navController.popBackStack() }
            )
        }
    }
}
