package com.example.sajilmaqasat.di

import android.content.Context
import androidx.room.Room
import com.example.sajilmaqasat.data.AppDatabase
import com.example.sajilmaqasat.data.PipeRecordDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): AppDatabase {
        return Room.databaseBuilder(
            context,
            AppDatabase::class.java,
            "sajil_maqasat_db"
        ).build()
    }

    @Provides
    @Singleton
    fun providePipeRecordDao(db: AppDatabase): PipeRecordDao = db.pipeRecordDao()
}
