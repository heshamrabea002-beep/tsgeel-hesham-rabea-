package com.example.sajilmaqasat.ui.theme

import androidx.compose.ui.graphics.Color

val GreenPrimary = Color(0xFF2E7D32)
val GreenPrimaryDark = Color(0xFF66BB6A)
val BlueSecondary = Color(0xFF1565C0)
val BlueSecondaryDark = Color(0xFF64B5F6)
val BackgroundLight = Color(0xFFF6F8FA)
val BackgroundDark = Color(0xFF121212)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceDark = Color(0xFF1E1E1E)
