package com.example.sajilmaqasat.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.sajilmaqasat.data.PipeRecord
import java.io.File
import java.io.FileOutputStream

object CsvExporter {

    private val headers = listOf(
        "مقاس الماسورة", "نوع الخامة", "سرعة الماكينة", "RPM 1", "RPM 2", "RPM 3",
        "حرارات الفرن", "حرارات الرأس", "قطر الشفاط", "نوع الشفاط", "معدل الشفط",
        "بعد الحوض الأول", "نهاية الخط", "ملاحظات"
    )

    private fun escape(value: String): String = "\"${value.replace("\"", "\"\"")}\""

    private fun recordToRow(r: PipeRecord): String {
        val values = listOf(
            r.pipeSize, r.materialType, r.machineSpeed, r.rpm1, r.rpm2, r.rpm3,
            r.furnaceTemps, r.headTemps, r.suctionDiameter, r.suctionType, r.suctionRate,
            r.diameterAfterTank1, r.diameterAtLineEnd, r.notes
        )
        return values.joinToString(",") { escape(it) }
    }

    /** Export every record into one CSV file and return its content Uri. */
    fun exportAll(context: Context, records: List<PipeRecord>): Uri {
        val fileName = "سجل_المقاسات_${System.currentTimeMillis()}.csv"
        return writeAndGetUri(context, records, fileName)
    }

    /** Export a single record into its own CSV file and return its content Uri. */
    fun exportSingle(context: Context, record: PipeRecord): Uri {
        val fileName = "مقاس_${record.pipeSize.ifBlank { "بدون_اسم" }}_${System.currentTimeMillis()}.csv"
        return writeAndGetUri(context, listOf(record), fileName)
    }

    private fun writeAndGetUri(context: Context, records: List<PipeRecord>, fileName: String): Uri {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, fileName)

        FileOutputStream(file).use { fos ->
            // UTF-8 BOM so Excel opens the Arabic text correctly.
            fos.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))

            val sb = StringBuilder()
            sb.append(headers.joinToString(",") { escape(it) }).append("\n")
            records.forEach { sb.append(recordToRow(it)).append("\n") }

            fos.write(sb.toString().toByteArray(Charsets.UTF_8))
        }

        return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    }

    /** Opens the system share sheet (WhatsApp / Gmail / Drive / ...) for the given CSV uri. */
    fun shareCsv(context: Context, uri: Uri) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "مشاركة ملف Excel"))
    }
}
