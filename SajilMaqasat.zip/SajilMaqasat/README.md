# سجل المقاسات

تطبيق أندرويد أصلي (Kotlin + Jetpack Compose + Room) لتسجيل بيانات خط إنتاج
مواسير بلاستيك، يعمل بالكامل أوفلاين، مع تصدير Excel (CSV) و PDF.

## طريقة التشغيل

1. افتح مجلد المشروع في **Android Studio** (إصدار Koala 2024.1 أو أحدث).
2. اضغط **Sync Now** لتنزيل الاعتماديات (Room, Hilt, Navigation Compose...).
3. شغّل التطبيق على جهاز حقيقي أو محاكي (Android 7.0 / API 24 فأعلى).

> ملاحظة: المشروع لا يحتوي على `gradle-wrapper.jar`. عند فتحه لأول مرة في
> Android Studio سيقوم البرنامج تلقائيًا بإنشاء الـ wrapper، أو يمكنك تشغيل
> `gradle wrapper` يدويًا إذا كان لديك Gradle مثبت على جهازك.

## البنية

```
app/src/main/java/com/example/sajilmaqasat/
├── data/            # PipeRecord (Entity) + DAO + AppDatabase + Repository
├── di/              # وحدة Hilt لحقن قاعدة البيانات
├── navigation/       # NavGraph (3 شاشات)
├── util/            # CsvExporter (Excel) + PdfExporter (WebView + PrintManager)
└── ui/
    ├── theme/       # ألوان Material 3 (أخضر #2E7D32 / أزرق #1565C0)
    ├── home/        # الشاشة الرئيسية + بحث فوري
    ├── addedit/     # شاشة الإضافة/التعديل (7 كروت، حرارات ديناميكية)
    └── detail/      # شاشة التفاصيل
```

## الميزات

- عمل أوفلاين بالكامل، بدون أي اتصال إنترنت أو API خارجي.
- بحث فوري (Live) بمقاس الماسورة.
- حقول حرارات الفرن والرأس ديناميكية (إضافة/حذف مناطق).
- تصدير كل السجلات أو سجل واحد إلى CSV متوافق مع Excel (BOM للعربي)
  ومشاركته عبر واتساب/جيميل/درايف.
- تصدير PDF عبر WebView + PrintManager الأصلي في أندرويد (بدون مكتبات خارجية).
- دعم كامل للغة العربية و RTL، ووضع ليلي.
- معمارية MVVM مع Hilt و StateFlow و Navigation Compose.
